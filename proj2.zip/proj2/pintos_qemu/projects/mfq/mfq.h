#ifndef __PROJECTS_PROJECT2_MFQ_H__
#define __PROJECTS_PROJECT2_MFQ_H__

void run_mfqtest(char **argv);

#endif /* __PROJECTS_PROJECT2_MFQ_H__ */