#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "threads/init.h"
#include "threads/malloc.h"
#include "threads/palloc.h"
#include "threads/thread.h"
#include "projects/pa/pa.h"

void run_patest(char **argv)
{   
    /// TODO: make your own test
    palloc_get_status(0);
    char test[3];
    test[0] = malloc(128000); //128K
    palloc_get_status(0);
    test[1] = malloc(256000); //256K
    palloc_get_status(0);
    test[2] = malloc(64000); //64K
    palloc_get_status(0);
    free(test[0]);
    free(test[1]);
    free(test[2]);
}