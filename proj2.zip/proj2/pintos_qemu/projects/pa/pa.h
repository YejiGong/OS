#ifndef __PROJECTS_PROJECT2_PA_H__
#define __PROJECTS_PROJECT2_PA_H__

void run_patest(char **argv);

#endif /* __PROJECTS_PROJECT2_PA_H__ */