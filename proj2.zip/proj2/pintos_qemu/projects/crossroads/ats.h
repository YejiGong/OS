#ifndef __PROJECTS_PROJECT1_ATS_H__
#define __PROJECTS_PROJECT1_ATS_H__

void* unitstep_changed();

#endif /* __PROJECTS_PROJECT1_ATS_H__ */
